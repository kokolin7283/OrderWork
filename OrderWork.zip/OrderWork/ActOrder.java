package com.example.kokolin.orderwork;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActOrder extends Activity implements AdapterView.OnItemClickListener {

    Mydb helper;
    String[] Order = new String[3];
    String[] DrinkName;
    int[] Mprice;
    int[] Lprice;



    private View.OnClickListener btnGoCart_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Orderdb helper = new Orderdb(ActOrder.this,"table1.db",null,1);
            Cursor c = helper.getReadableDatabase().query("table1",null,null,
                    null,null,null,null);

            int row = c.getCount();
            if(row > 0){
                Intent i = new Intent(ActOrder.this , ActCart.class);
                startActivity(i);

            }else{

                c.moveToFirst();
                c.close();
                helper.close();
                Toast.makeText(ActOrder.this,"尚無購物紀錄",Toast.LENGTH_SHORT).show();
            }

        }
    };


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    class Myadapter extends BaseAdapter {

        Context myContext;
        LayoutInflater inflater;
        TextView txtTitle;
        ViewHolder holder;

        public Myadapter(Context context){
            this.myContext = context;
            inflater = LayoutInflater.from(this.myContext);
        }

        @Override
        public int getCount() {
            return DrinkName.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if(convertView == null){
                holder = new Myadapter.ViewHolder();
                convertView = inflater.inflate(R.layout.mylayout , null);
                holder.imageView1 = convertView.findViewById(R.id.imageView1);
                holder.imgPlus = convertView.findViewById(R.id.imgPlus);
                holder.txtTitle = convertView.findViewById(R.id.txtTitle);
                holder.txtMprice = convertView.findViewById(R.id.txtMprice);
                holder.txtLprice = convertView.findViewById(R.id.txtLprice);
                convertView.setTag(holder);
            }else{
                holder = (Myadapter.ViewHolder) convertView.getTag();
            }
            holder.imageView1.setImageResource(R.drawable.milkshake64);
            holder.imgPlus.setImageResource(R.drawable.plus);
            holder.txtTitle.setText(DrinkName[position]);
            holder.txtMprice.setText(String.valueOf(Mprice[position]));
            holder.txtLprice.setText(Integer.toString(Lprice[position]));

            return convertView;
        }

        class ViewHolder{
            TextView txtTitle;
            TextView txtMprice;
            TextView txtLprice;
            ImageView imageView1;
            ImageView imgPlus;
        }
    }



    public void getDrinkName(){
        Mydb helper = new Mydb(ActOrder.this,"ttable01.db",null,1);
        Cursor c = helper.getReadableDatabase().query("ttable01",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            DrinkName = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                DrinkName[i] = c.getString(1);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getMprice(){
        Mydb helper = new Mydb(ActOrder.this,"ttable01.db",null,1);
        Cursor c = helper.getReadableDatabase().query("ttable01",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            Mprice = new int[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                Mprice[i] = c.getInt(4);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getLprice(){
        Mydb helper = new Mydb(ActOrder.this,"ttable01.db",null,1);
        Cursor c = helper.getReadableDatabase().query("ttable01",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            Lprice = new int[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                Lprice[i] = c.getInt(5);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actorder);
        initialcomponent();
        getDrinkName();
        getMprice();
        getLprice();

        Myadapter adapter = new Myadapter(ActOrder.this);

        listView1.setAdapter(adapter);

        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bund = new Bundle();
                Order[0] = DrinkName[position];
                Order[1] = String.valueOf(Mprice[position]);
                Order[2] = String.valueOf(Lprice[position]);
                bund.putStringArray(CDictionary.SELECTED_DRINKNAME , Order);
                Intent i = new Intent(ActOrder.this , Actshop.class);
                i.putExtras(bund);
                startActivity(i);
            }
        });

    }

    private void initialcomponent() {
        listView1 = findViewById(R.id.listView1);
        btnGoCart = findViewById(R.id.btnGoCart);
        btnGoCart.setOnClickListener(btnGoCart_click);


    }

    ListView listView1;
    Button btnGoCart;



}
