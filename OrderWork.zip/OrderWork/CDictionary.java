package com.example.kokolin.orderwork;

public class CDictionary {
    public static final String SELECTED_DRINKNAME = "SELECTED_DRINKNAME";

}
