package com.example.kokolin.orderwork;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Actmenu extends Activity {

    Mydb helper;
    String[] DrinkName;


    private View.OnClickListener btnStart_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent i = new Intent(Actmenu.this , ActOrder.class);
            startActivity(i);
        }
    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmenu);
        initialcomponent();


    }


    private void initialcomponent() {
        btnStart = findViewById(R.id.btnStart);
        btnStart.setOnClickListener(btnStart_click);
        btnBack = findViewById(R.id.btnBack);

        txtTestString = findViewById(R.id.txtTestString);

    }

    Button btnStart,btnBack;

    TextView txtTestString;





}
