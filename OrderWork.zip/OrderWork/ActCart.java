package com.example.kokolin.orderwork;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ActCart extends Activity {

    String[] DrinkName;
    String[] tempstatus;
    String[] cupCount;
    String[] cupSize;
    String[] price;
    String[] sugar;
    String[] Ice;
    int totalMoney=0;





    private View.OnClickListener btnSendout_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            deleteDatabase("table1.db");
            ActCart.this.finish();
        }
    };

    private View.OnClickListener btnBackorder_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ActCart.this.finish();
        }
    };







    class MyCartAdapter extends BaseAdapter {

        Context myContext;
        LayoutInflater inflater;

        public MyCartAdapter(Context context){
            this.myContext = context;
            inflater = LayoutInflater.from(this.myContext);
        }


        @Override
        public int getCount() {
            return DrinkName.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            convertView = inflater.inflate(R.layout.cartlistlayout , null);
            ImageView imageViewCart = convertView.findViewById(R.id.imageViewCart);
            ImageView imageViewEdit = convertView.findViewById(R.id.imageViewEdit);
            TextView txtTitle = convertView.findViewById(R.id.txtTitle);
            TextView txtTotalPrice = convertView.findViewById(R.id.txtTotalPrice);
            TextView txtCupNum = convertView.findViewById(R.id.txtCupNum);
            TextView txtPrice = convertView.findViewById(R.id.txtPrice);
            TextView txtOrderStatus = convertView.findViewById(R.id.txtOrderStatus);

            imageViewCart.setImageResource(R.drawable.drink);
            imageViewEdit.setImageResource(R.drawable.edit);


            txtTitle.setText(DrinkName[position]);
            int totalprice = (Integer.parseInt(price[position]) * Integer.parseInt(cupCount[position]));
            totalMoney += totalprice;

            txtTotalPrice.setText(String.valueOf(totalprice));
            txtCupNum.setText(cupCount[position]);
            txtPrice.setText(price[position]);
            txtOrderStatus.setText(txtOrderStatus.getText().toString()+ "\n" + tempstatus[position] + "、" +cupSize[position] + "、" + sugar[position] + "、" + Ice[position]);

            return convertView;

        }



    }

    public void getDrinkName(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            DrinkName = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                DrinkName[i] = c.getString(1);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void gettempstatus(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            tempstatus = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                tempstatus[i] = c.getString(2);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getcupCount(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            cupCount = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                cupCount[i] = c.getString(3);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getcupSize(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            cupSize = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                cupSize[i] = c.getString(4);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getprice(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            price = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                price[i] = c.getString(5);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getsugar(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            sugar = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                sugar[i] = c.getString(6);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }

    public void getIce(){
        Orderdb helper = new Orderdb(ActCart.this,"table1.db",null,1);
        Cursor c = helper.getReadableDatabase().query("table1",null,null,
                null,null,null,null);
        int row = c.getCount();
        if(row != 0){
            Ice = new String[row];
            c.moveToFirst();
            for(int i =0; i < row;i++){
                Ice[i] = c.getString(7);
                c.moveToNext();
            }
        }
        c.close();
        helper.close();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actcart);
        initialcomponent();
        getDrinkName();
        gettempstatus();
        getcupCount();
        getcupSize();
        getprice();
        getsugar();
        getIce();

        MyCartAdapter adapter = new MyCartAdapter(ActCart.this);
        listViewOrder.setAdapter(adapter);
        listViewOrder.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

        for(int i=0; i < price.length ; i++){
            totalMoney +=Integer.valueOf(price[i]) * Integer.valueOf(cupCount[i]);
        }
        txtTotalMoney.setText(String.valueOf(totalMoney));


    }

    private void initialcomponent() {
        listViewOrder = findViewById(R.id.listViewOrder);
        txtTotalMoney = findViewById(R.id.txtTotalMoney);


        btnSendout = findViewById(R.id.btnSendout);
        btnSendout.setOnClickListener(btnSendout_click);
        btnBackorder = findViewById(R.id.btnBackorder);
        btnBackorder.setOnClickListener(btnBackorder_click);
    }

    Button btnSendout;
    Button btnBackorder;
    ListView listViewOrder;
    TextView txtTotalMoney;
}
