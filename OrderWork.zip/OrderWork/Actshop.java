package com.example.kokolin.orderwork;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Actshop extends Activity {

    String[] Order = new String[3];
    Orderdb helper;
    String cupSize = "M";
    String Price = "";
    String Tempstatus = "冷飲";
    String Sugarstatus = "正常糖";
    String Icestatus = "正常冰";

    //關掉本頁回前頁
    private View.OnClickListener btnBack_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Actshop.this.finish();
        }
    };

    //杯數+1
    private View.OnClickListener btnPlus_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            edCount.setText(SetCountPlus(edCount.getText().toString()));
        }
    };

    //杯數-1
    private View.OnClickListener btnMinus_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            edCount.setText(SetCountMinus(edCount.getText().toString()));

        }
    };


    private RadioGroup.OnCheckedChangeListener radioTemp_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radioTempA1){
                Tempstatus = radioTempA1.getText().toString();
                radioIceA1.setEnabled(true);
                radioIceA2.setEnabled(true);
                radioIceA3.setEnabled(true);
                radioIceA4.setEnabled(true);
            }
            else if (checkedId == R.id.radioTempA2){
                Tempstatus = radioTempA2.getText().toString();
                radioIceA1.setEnabled(false);
                radioIceA2.setEnabled(false);
                radioIceA3.setEnabled(false);
                radioIceA4.setEnabled(false);
                radioIceA1.setChecked(false);
                radioIceA2.setChecked(false);
                radioIceA3.setChecked(false);
                radioIceA4.setChecked(false);
                Icestatus = "";
            }


        }
    };

    private RadioGroup.OnCheckedChangeListener radioPrice_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.rdbMprice) {
                Price = rdbMprice.getText().toString();
                cupSize = "M";}
            else if (checkedId == R.id.rdbLprice){
                Price = rdbLprice.getText().toString();
                cupSize = "L";}
        }
    };

    private RadioGroup.OnCheckedChangeListener radioSugar_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radioSugarA1)
                Sugarstatus = radioSugarA1.getText().toString();
            else if (checkedId == R.id.radioSugarA2)
                Sugarstatus = radioSugarA2.getText().toString();
            else if (checkedId == R.id.radioSugarA3)
                Sugarstatus = radioSugarA3.getText().toString();
            else if (checkedId == R.id.radioSugarA4)
                Sugarstatus = radioSugarA4.getText().toString();
            else if (checkedId == R.id.radioSugarA5)
                Sugarstatus = radioSugarA5.getText().toString();
        }
    };

    private RadioGroup.OnCheckedChangeListener radioIce_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radioIceA1)
                Icestatus = radioIceA1.getText().toString();
            else if (checkedId == R.id.radioIceA2)
                Icestatus = radioIceA2.getText().toString();
            else if (checkedId == R.id.radioIceA3)
                Icestatus = radioIceA3.getText().toString();
            else if (checkedId == R.id.radioIceA4)
                Icestatus = radioIceA4.getText().toString();
        }
    };



    //購買
    private View.OnClickListener btnBuy_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if(edCount.getText().toString().equals("0")){
                Toast.makeText(Actshop.this, "杯數不可為零", Toast.LENGTH_SHORT).show();
            }else{
                try {
                    helper = new Orderdb(Actshop.this, "table1.db", null, 1);
                    ContentValues values = new ContentValues();
                    values.put("name", Order[0].toString());
                    values.put("tempstatus", Tempstatus);
                    values.put("cupCount", Integer.valueOf(edCount.getText().toString()) );
                    values.put("cupSize", cupSize);
                    values.put("price", Integer.valueOf(Price.toString()));
                    values.put("sugar", Sugarstatus);
                    values.put("Ice", Icestatus);
                    long id = helper.getWritableDatabase().insert("table1", null, values);
                }catch (Exception e){
                    Toast.makeText(Actshop.this,"請輸入杯數",Toast.LENGTH_LONG).show();
                    return;
                }


                Toast.makeText(Actshop.this, "訂購成功", Toast.LENGTH_SHORT).show();

                Actshop.this.finish();
            }
        }
    };





    private String SetCountPlus(String Count){
        if (Count.equals(""))
            Count = "1";
        else
        if(Integer.parseInt(Count) >= 0){
            int num = Integer.parseInt(Count);
            num ++;
            Count = Integer.toString(num);
        }else
            Count = "1";
        return Count;
    }

    private String SetCountMinus(String Count){
        if (Count.equals(""))
            Count = "0";
        if(Integer.parseInt(Count) > 0){
            int num = Integer.parseInt(Count);
            num --;
            Count = Integer.toString(num);
        }else
            Count = "0";
        return Count;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actshop);
        initialcomponent();

        Order = getIntent().getExtras().getStringArray(CDictionary.SELECTED_DRINKNAME);
        txtShopTitle.setText(Order[0]);
        rdbMprice.setText(Order[1]);
        rdbLprice.setText(Order[2]);
        Price = Order[1].toString(); //rdbMprice.getText().toString();



    }



    private void initialcomponent() {
        txtShopTitle = findViewById(R.id.txtShopTitle);
        rdbMprice = findViewById(R.id.rdbMprice);
        rdbLprice = findViewById(R.id.rdbLprice);

        radioTempA1 = findViewById(R.id.radioTempA1);
        radioTempA2 = findViewById(R.id.radioTempA2);
        radioSugarA1 = findViewById(R.id.radioSugarA1);
        radioSugarA2 = findViewById(R.id.radioSugarA2);
        radioSugarA3 = findViewById(R.id.radioSugarA3);
        radioSugarA4 = findViewById(R.id.radioSugarA4);
        radioSugarA5 = findViewById(R.id.radioSugarA5);
        radioIceA1 = findViewById(R.id.radioIceA1);
        radioIceA2 = findViewById(R.id.radioIceA2);
        radioIceA3 = findViewById(R.id.radioIceA3);
        radioIceA4 = findViewById(R.id.radioIceA4);

        edCount = findViewById(R.id.edCount);

        btnMinus = findViewById(R.id.btnMinus);
        btnMinus.setOnClickListener(btnMinus_click);

        btnPlus = findViewById(R.id.btnPlus);
        btnPlus.setOnClickListener(btnPlus_click);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(btnBack_click);

        btnBuy = findViewById(R.id.btnBuy);
        btnBuy.setOnClickListener(btnBuy_click);

        radioTemp = findViewById(R.id.radioTemp);
        radioTemp.setOnCheckedChangeListener(radioTemp_click);

        radioPrice = findViewById(R.id.radioPrice);
        radioPrice.setOnCheckedChangeListener(radioPrice_click);

        radioSugar = findViewById(R.id.radioSugar);
        radioSugar.setOnCheckedChangeListener(radioSugar_click);

        radioIce = findViewById(R.id.radioIce);
        radioIce.setOnCheckedChangeListener(radioIce_click);

    }

    TextView txtShopTitle;

    Button btnBack;
    Button btnPlus;
    Button btnMinus;
    Button btnBuy;
    EditText edCount;

    RadioButton rdbMprice;
    RadioButton rdbLprice;

    RadioGroup radioTemp;
    RadioGroup radioPrice;
    RadioGroup radioSugar;
    RadioGroup radioIce;


    RadioButton radioTempA1;
    RadioButton radioTempA2;

    RadioButton radioSugarA1;
    RadioButton radioSugarA2;
    RadioButton radioSugarA3;
    RadioButton radioSugarA4;
    RadioButton radioSugarA5;

    RadioButton radioIceA1;
    RadioButton radioIceA2;
    RadioButton radioIceA3;
    RadioButton radioIceA4;





}
