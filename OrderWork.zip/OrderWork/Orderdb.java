package com.example.kokolin.orderwork;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Orderdb extends SQLiteOpenHelper {
    public Orderdb(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE table1" +
                "(_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name VARCHAR(20)," +
                "tempstatus VARCHAR(10)," +
                "cupCount INTEGER," +
                "cupSize VARCHAR(10)," +
                "price INTEGER," +
                "sugar VARCHAR(10)," +
                "Ice VARCHAR(10))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
