package com.example.kokolin.orderwork;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class CreateStoredb {

    public void onCreate(Context act){
        try{
            Mydb helper = new Mydb(act , "ttable01.db",null,1);
            ContentValues values = new ContentValues();
            Cursor c = helper.getReadableDatabase().query("ttable01",null,null,null
            ,null,null,null);

            if(c.getCount() == 0){

                values.put("name","紅茶");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 25);
                values.put("priceL" , 30);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","綠茶");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 25);
                values.put("priceL" , 30);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","奶茶");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 35);
                values.put("priceL" , 40);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","烏龍茶");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 25);
                values.put("priceL" , 30);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","青茶");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 25);
                values.put("priceL" , 30);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","波霸奶茶");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 40);
                values.put("priceL" , 45);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","紅茶拿鐵");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 50);
                values.put("priceL" , 55);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","多多綠");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 35);
                values.put("priceL" , 40);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","鮮榨檸檬汁");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 35);
                values.put("priceL" , 40);
                helper.getWritableDatabase().insert("ttable01", null, values);
                values.put("name","百香果汁");
                values.put("coldstatus","1");
                values.put("hotstatus" , "1");
                values.put("priceM" , 35);
                values.put("priceL" , 40);
                helper.getWritableDatabase().insert("ttable01", null, values);
            }




        }catch (Exception ex){

        }



    }
}
