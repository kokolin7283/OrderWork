package com.example.kokolin.orderwork;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.database.Cursor;
import android.app.ActivityOptions;
import android.widget.Toast;


public class Actmain extends Activity {
    Mydb helper;


    private View.OnClickListener btnStart_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            openDb();
            openOrderDb();
            Intent i = new Intent(Actmain.this , Actmenu.class);
            startActivity(i);

        }
    };
    private View.OnClickListener btnDeletedb_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            deleteDatabase("ttable01.db");
            deleteDatabase("table1.db");
            Toast.makeText(Actmain.this,"紀錄已清除",Toast.LENGTH_SHORT).show();
        }
    };


    public void openDb(){
        SQLiteDatabase db = openOrCreateDatabase("ttable01" , MODE_PRIVATE , null);
        try{
            CreateStoredb StoreDb = new CreateStoredb();
            StoreDb.onCreate(Actmain.this);
        }catch(Exception ex){

        }
    }

    public void openOrderDb(){
        SQLiteDatabase db = openOrCreateDatabase("table1" , MODE_PRIVATE , null);
        try{
            CreateStoredb StoreDb = new CreateStoredb();
            StoreDb.onCreate(Actmain.this);
        }catch(Exception ex){

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        initialcomponent();
        openDb();
        openOrderDb();
    }



    private void initialcomponent() {
        btnStart = findViewById(R.id.btnStart);
        btnStart.setOnClickListener(btnStart_click);
        btnDeletedb = findViewById(R.id.btnDeletedb);
        btnDeletedb.setOnClickListener(btnDeletedb_click);

    }

    Button btnStart;
    Button btnDeletedb;
}
